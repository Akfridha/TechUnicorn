﻿namespace UnicornProject.Helper
{
    public static class ConnectionString
    {
        public static string HospitalAppionmentConnectionString { get; set; }
    }
}
