﻿namespace UnicornProject.Helper
{
    public enum RoleEnum
    {
        Patient = 1,
        Doctors,
        ClinicAdmins

    }

}
