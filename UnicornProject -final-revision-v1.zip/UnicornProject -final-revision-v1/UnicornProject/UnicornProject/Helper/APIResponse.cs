﻿namespace UnicornProject.Helper
{
    public class APIResponse
    {
        public bool Status { get; set; }

        public dynamic Data { get; set; }

        public string StatusMessage { get; set; }
    }
}
