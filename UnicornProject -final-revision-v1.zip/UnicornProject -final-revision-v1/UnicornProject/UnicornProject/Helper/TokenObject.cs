﻿using System;

namespace UnicornProject.Helper
{
    public class TokenObject
    {
        public string token { get; set; }

        public DateTime expires { get; set; }
    }
}
