from flask import Flask,send_from_directory,render_template
from flask_restful import Resource, Api
from package.patient import Patients, Patient,Patient_Appointment, Patient_Previous_Appointments
from package.doctor import Doctors, Doctor,Doctor_Slot,Doctor_Appointment,Doctor_Cancel_Appointment
from package.appointment import Appointments, Appointment
from package.admin import Admin_Patient, Admin_Doctor, Admin_Doctor_Appointment, Cancel_Appointment, Admin_most_Appointment, Doctors_exceeding_hours
from package.model import conn
import json


with open('config.json') as data_file:
    config = json.load(data_file)

app = Flask(__name__, static_url_path='')
api = Api(app)

api.add_resource(Patients, '/registration') # Registering Patient/ Viewing list of patients
api.add_resource(Patient, '/patient/<int:id>') # patient details
api.add_resource(Patient_Appointment,'/patient/<int:id>/appointment') # Today's appointments of patient
api.add_resource(Patient_Previous_Appointments,'/patient/<int:id>/appHistory') # Patients previous appointments
api.add_resource(Doctors, '/doctor') # list of doctors / registering doctors
api.add_resource(Doctor, '/doctor/<int:id>') # doctors details
api.add_resource(Doctor_Slot, '/doctor/<int:id>/slots') # doctors available slots
api.add_resource(Doctor_Appointment, '/doctor/<int:id>/appointment') #doctor viewing his appointments
api.add_resource(Doctor_Cancel_Appointment.'/doctor_cancel_appointment/<int:id>') #Cancelling appointment based on Appointment id
api.add_resource(Appointments, '/appointment') #Viewing list of appointments
api.add_resource(Appointment, '/appointment/<int:id>/<int:pid>') # Patient viewing Doctors Appointments
api.add_resource(Admin_Patient, '/admin_patient') #List patient details
api.add_resource(Admin_Doctor, '/admin_doctor') #List Doctor details
api.add_resource(Admin_Doctor_Appointment, '/admin_doctor_appointment/<int:id>') #List Doctor Appointment details
api.add_resource(Cancel_Appointment, '/cancel_appointment/<int:id>') #Cancel Appointment
api.add_resource(Admin_most_Appointment, '/most_appointment') # Most Appointment received for the doctor
api.add_resource(Doctors_exceeding_hours, '/doctors_exceeding_hours') #Hours excedd for the doctor

# Routes

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route("/login",methods = ['GET'])
def Login():
    Credentials = conn.execute("SELECT * FROM patient").fetchall()
    return Credentials


if __name__ == '__main__':
    app.run(debug=True,host=config['host'],port=config['port'])