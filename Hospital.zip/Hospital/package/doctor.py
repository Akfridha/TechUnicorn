from flask_restful import Resource, Api, request
from package.model import conn


class Doctors(Resource):
    """This contain apis to carry out activity with all doctors"""

    def get(self):
        """Retrive list of all the doctor"""

        doctors = conn.execute("SELECT * FROM doctors").fetchall()
        return doctors



    def post(self):
        """Add the new doctor"""

        doctorInput = request.get_json(force=True)
        doc_first_name=doctorInput['doc_first_name']
        doc_last_name = doctorInput['doc_last_name']
        doc_ph_no = doctorInput['doc_ph_no']
        doc_address = doctorInput['doc_address']
        doctorInput['doc_id']=conn.execute('''INSERT INTO doctors(doc_first_name,doc_last_name,doc_ph_no,doc_address)
            VALUES(?,?,?,?)''', (doc_first_name, doc_last_name,doc_ph_no,doc_address)).lastrowid
        conn.commit()
        return doctorInput

class Doctor(Resource):
    """It include all the apis carrying out the activity with the single doctor"""


    def get(self,id):
        """get the details of the docktor by the doctor id"""

        doctor = conn.execute("SELECT * FROM doctors WHERE doc_id=?",(id,)).fetchall()
        print("Hello")
        return doctor

    def delete(self, id):
        """Delete the doctor by its id"""

        conn.execute("DELETE FROM doctors WHERE doc_id=?", (id,))
        conn.commit()
        return {'msg': 'sucessfully deleted'}

    def put(self,id):
        """Update the doctor by its id"""

        doctorInput = request.get_json(force=True)
        doc_first_name=doctorInput['doc_first_name']
        doc_last_name = doctorInput['doc_last_name']
        doc_ph_no = doctorInput['doc_ph_no']
        doc_address = doctorInput['doc_address']
        conn.execute(
            "UPDATE doctors SET doc_first_name=?,doc_last_name=?,doc_ph_no=?,doc_address=? WHERE doc_id=?",
            (doc_first_name, doc_last_name, doc_ph_no, doc_address, id))
        conn.commit()
        return doctorInput

class Doctor_Appointment(Resource):
    def get(self,id):
        appointment = conn.execute("SELECT p.*,a.* from slots_final a LEFT JOIN patients p ON a.pat_id = p.pat_id where doc_id=?",(id,)).fetchall()
        return appointment


    def delete(self,id):

        conn.execute("DELETE FROM slots_final WHERE app_id=?",(id,))
        conn.commit()
        return {'msg': 'sucessfully deleted'}
        

class Doctor_Slot(Resource):
   
    def get(self,id):
        doctor_slot = conn.execute("SELECT slot FROM slots_final WHERE doc_id=?",(id,)).fetchall()
        # conn.execute(
        #     "UPDATE slots SET slot=?,appointment_date=? WHERE pat_id=?",
        #     ("11-11.30", "20-07-2022",2))
        # conn.commit()
       
        # return "updated"
        if len(doctor_slot)==0:
            message = "Doctor is available from 9AM to 12PM and 1PM to 6PM."
            return message
        else:
            if len(doctor_slot)==12:
                return "Slots are full for the selected doctor."
            else:
                doctor_slot = [item['slot'] for item in doctor_slot]
                timings = [item.split('-') for item in doctor_slot]
                available_slots = []
                duration = []
                timings = sorted(timings)
                print(timings)
                for i in range(0,len(timings)):
                    if i==0:
                        if timings[i][0]!='9':
                            available_slots.append('9'+'-'+timings[i][0])
                    if i+1 < len(timings):
                        print("i",i)
                        if float(timings[i][1])<float(timings[i+1][0]):
                            available_slots.append(timings[i][1]+'-'+timings[i+1][0])
                        if float(timings[i][1])>float(timings[i+1][0]):
                            available_slots.append(timings[i][1]+'-'+timings[i+1][0])
                    else:
                        if float(timings[i][1]) > 9:
                            available_slots.append(timings[i][1]+'-'+'6')
                           
                        else:
                            if float(timings[i][1]) < 6:
                                available_slots.append(timings[i][1]+'-'+'6')
                if len(available_slots)==0:
                    return "Slots are full for the selected doctor."
                return available_slots

