

from flask_restful import Resource, Api, request
from package.model import conn
from datetime import datetime


class Admin_Patient(Resource):
    def get(self):
        getPatientDetails=conn.execute("SELECT * FROM patients").fetchall()
        return getPatientDetails

class Admin_Doctor(Resource):
    def get(self):
        getDoctorDetails = conn.execute("SELECT * FROM doctors").fetchall()
        return getDoctorDetails

class Admin_Doctor_Appointment(Resource):
    def get(self,id):
        now = datetime.now()
        date_time_str = now.strftime("%d-%m-%Y")
        appointment = conn.execute("SELECT p.*,a.* from slots_final a LEFT JOIN patients p ON a.pat_id = p.pat_id where doc_id=? and appointment_date=?",(id,date_time_str)).fetchall()
        return appointment

class Cancel_Appointment(Resource):
    def delete(self,id):

        conn.execute("DELETE FROM slots_final WHERE app_id=?",(id,))
        conn.commit()
        return {'msg': 'sucessfully deleted'}

class Admin_most_Appointment(Resource):
    """This contain apis to carry out activity with admin"""

    def get(self):
        """Retrive list of all the doctor"""

        doctorslist = conn.execute("SELECT doc_id FROM doctors").fetchall()
        doctorslist = [item['doc_id'] for item in doctorslist]
        doctor_dict = {}
        for doctor_id in doctorslist:
            count = conn.execute("SELECT count(doc_id) as doc_id from slots WHERE doc_id=?",(doctor_id,)).fetchall()
            doctor_dict[doctor_id]=count[0]['doc_id']
            doctor_dict = {k: v for k, v in sorted(doctor_dict.items(), key=lambda item: item[1])}
            sorted_list = list(doctor_dict.keys())[::-1]
        return sorted_list

class Doctors_exceeding_hours(Resource):
    def get(self):
        """Retrive list of all the doctor"""

        doctorslist = conn.execute("SELECT doc_id FROM doctors").fetchall()
        doctorslist = [item['doc_id'] for item in doctorslist]
        doctors_exceeding_hours = []
        for doctor_id in doctorslist:
            doctor_slot = conn.execute("SELECT slot FROM slots WHERE doc_id=?",(doctor_id,)).fetchall()
            if len(doctor_slot)!=0:
                doctor_slot = [item['slot'] for item in doctor_slot]
                timings = [item.split('-') for item in doctor_slot]
                available_slots = []
                duration = []
                timings = sorted(timings)
                print(timings)
                for item in timings:
                    if float(item[0])<float(item[1]):
                        right = item[1].split('.')
                        if len(right)==1:
                            right_time = int(right[0])*60
                        else:
                            right_time = (int(right[0])*60)+int(right[1])
                        left = item[0].split('.')
                        if len(left)==1:
                            left_time = int(left[0])*60
                        else:
                            left_time = (int(left[0])*60)+int(left[1])
                       
                        duration.append(right_time-left_time)
                    else:
                        right = item[1].split('.')
                        if len(right)==1:
                            right_time = (11+int(right[0]))*60
                        else:
                            right_time = ((11+int(right[0]))*60)+int(right[1])
                        print(right_time)
                        left = item[0].split('.')
                        if len(left)==1:
                            left_time = int(left[0])*60
                        else:
                            left_time = (int(left[0])*60)+int(left[1])
                        print(left_time)
                       
                        duration.append(right_time-left_time)
                if (sum(duration)/60) > 6.0:
                    doctors_exceeding_hours.append(doctor_id)
                   
                   
        return doctors_exceeding_hours
        