from flask_restful import Resource, Api, request
from package.model import conn



class Appointments(Resource):
    """This contain apis to carry out activity with all appiontments"""

    def get(self):
        """Retrive all the appointment and return in form of json"""
       
        appointment = conn.execute("SELECT p.*,d.*,a.* from slots_final a LEFT JOIN patients p ON a.pat_id = p.pat_id LEFT JOIN doctors d ON a.doc_id = d.doc_id ORDER BY appointment_date DESC").fetchall()
        return appointment

    def post(self):

        appointment = request.get_json(force=True)
        pat_id = appointment['pat_id']
        doc_id = appointment['doc_id']
        appointment_date = appointment['appointment_date']
        slot = appointment['slot']
        appointment['app_id'] = conn.execute('''INSERT INTO slots_final(pat_id,doc_id,appointment_date,slot)
            VALUES(?,?,?,?)''', (pat_id, doc_id,appointment_date,slot)).lastrowid
        conn.commit()
        return appointment



class Appointment(Resource):

    def get(self,id):

        appointment = conn.execute("SELECT pat_id,appointment_date,slot FROM slots_final WHERE doc_id=?",(id,)).fetchall()
        if len(appointment)==0:
            return "No appointments for the given doctor"
        else:
            return appointment


    def delete(self,id):
        """Delete teh appointment by its id"""

        conn.execute("DELETE FROM slots_final WHERE app_id=?",(id,))
        conn.commit()
        return {'msg': 'sucessfully deleted'}

    def put(self,id):
        """Update the appointment details by the appointment id"""

        appointment = request.get_json(force=True)
        pat_id = appointment['pat_id']
        doc_id = appointment['doc_id']
        conn.execute("UPDATE slots_final SET pat_id=?,doc_id=? WHERE app_id=?",
                     (pat_id, doc_id, id))
        conn.commit()
        return appointment